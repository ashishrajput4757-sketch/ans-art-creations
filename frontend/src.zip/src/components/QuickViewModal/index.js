export { default } from './QuickViewModal';
