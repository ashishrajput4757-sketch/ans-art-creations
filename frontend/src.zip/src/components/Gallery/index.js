export { default } from './Gallery';
